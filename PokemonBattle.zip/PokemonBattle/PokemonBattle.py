#Pokemon Battle Py
import tkinter as tk                            #Import the tkinter library
from tkinter import PhotoImage          #Import the photo library from tkinter
import time
import random

#Attack Class
class Attack:
    def __init__(self, name, damage):
        self.name = name
        self.damage = damage

#Pokemon Class
class Pokemon:
    def __init__(self, name, health, attack, defence, attack1, attack2, attack3, attack4):
        self.name = name
        self.health = health
        self.attack = attack
        self.defence = defence
        self.attack1 = attack1
        self.attack2 = attack2
        self.attack3 = attack3
        self.attack4 = attack4

#Global Variables
slash = Attack("SLASH", 70)
flamethrower = Attack("FLAMETHROWER", 90)
wing_attack = Attack("WING ATTACK", 60)
ember = Attack("EMBER", 40)
night_shade = Attack("NIGHT SHADE", 50)
psychic = Attack("PSYCHIC", 90)
body_slam = Attack("BODY SLAM", 85)
mega_punch = Attack("MEGA PUNCH", 80)

enpkmn = Pokemon("GENGAR", 60, 65, 60, night_shade, psychic, body_slam, mega_punch)           #Create Enemy Pokemon
frpkmn = Pokemon("CHARIZARD", 78, 84, 78, slash, flamethrower, wing_attack, ember)        #Create Friendly Pokemon

#Functions
def Random_attack():
    attacks_list = []
    attacks_list.append(enpkmn.attack1)
    attacks_list.append(enpkmn.attack2)
    attacks_list.append(enpkmn.attack3)
    attacks_list.append(enpkmn.attack4)
    random.shuffle(attacks_list)
    sel_attack = attacks_list[0].damage
    return sel_attack

def Call_attack(damage):
    Power = 2 * random.randint(1, 2) * damage * frpkmn.attack // enpkmn.defence // 25 + 2
    enpkmn.health = enpkmn.health - Power
    if enpkmn.health < 0:
        enpkmn.health = 0
        enemyhealth.destroy()
        enemyname.destroy()
        Enemypkmn.destroy()

        wintext = tk.Label(frame, text=(frpkmn.name, "WINS!"), bg="white", fg="black", font="bold 40")
        wintext.place(x=50, y=100, width=700, height=45)

    else:
        enemyhealth.config(text=("HP:", enpkmn.health))
        time.sleep(0)
        Power = 2 * random.randint(1, 2) * Random_attack() * enpkmn.attack // frpkmn.defence // 25 + 2
        frpkmn.health = frpkmn.health - Power
        friendlyhealth.config(text=("HP:", frpkmn.health))

#Create Main Window
frame = tk.Tk()                             #Create frame
frame.title("PokemonBattle")        #Create Window Title
frame.geometry("800x800")           #Set Window Size
frame.configure(bg="white")         #Set Window background to be white
frame.iconbitmap("pkmnLogo.ico")      #Set window icon

#Create Menu Interactable GUI
enemyim = PhotoImage(file="im_GengarFront.png").zoom(5, 5)
Enemypkmn = tk.Label(frame, image=enemyim, bg="white")
Enemypkmn.place(x=400, y=-100, width=500, height=500)

friendlyim = PhotoImage(file="im_CharizardBack.png").zoom(8, 8)
Friendlypkmn = tk.Label(frame, image=friendlyim, bg="white")
Friendlypkmn.place(x=-60, y=500, width=400, height=400)

enemyname = tk.Label(frame, text=enpkmn.name, bg="white", fg="black", font="bold 30")
enemyname.place(x=250, y=50, width=250, height=30)

friendlyname = tk.Label(frame, text=frpkmn.name, bg="white", fg="black", font="bold 30")
friendlyname.place(x=250, y=500, width=250, height=30)

enemyhealth = tk.Label(frame, text=("HP:", enpkmn.health), bg="white", fg="black", font="bold 20")
enemyhealth.place(x=250, y=90, width=250, height=20)

friendlyhealth = tk.Label(frame, text=("HP:", frpkmn.health), bg="white", fg="black", font="bold 20")
friendlyhealth.place(x=250, y=540, width=250, height=30)


Attack1 = tk.Button(frame, text=frpkmn.attack1.name, font="bold 15", command=lambda: Call_attack(frpkmn.attack1.damage))
Attack1.place(x=300, y=620, width=170, height=40)

Attack2 = tk.Button(frame, text=frpkmn.attack2.name, font="bold 15", command=lambda: Call_attack(frpkmn.attack2.damage))
Attack2.place(x=480, y=620, width=170, height=40)

Attack3 = tk.Button(frame, text=frpkmn.attack3.name, font="bold 15", command=lambda: Call_attack(frpkmn.attack3.damage))
Attack3.place(x=480, y=670, width=170, height=40)

Attack4 = tk.Button(frame, text=frpkmn.attack4.name, font="bold 15", command=lambda: Call_attack(frpkmn.attack4.damage))
Attack4.place(x=300, y=670, width=170, height=40)

frame.mainloop()
